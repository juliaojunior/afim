$("#mecButton").click(function(){
	$("#mec1").fadeToggle(500);
})

$("#calButton").click(function(){
	$("#cal1").fadeToggle(500);
})

$("#optButton").click(function(){
	$("#opt1").fadeToggle(500);
	$("#opt2").fadeToggle(500);
	$("#opt3").fadeToggle(500);
})

$("#ondButton").click(function(){
	$("#ond1").fadeToggle(500);
	$("#ond2").fadeToggle(500);
	$("#ond3").fadeToggle(500);
})

$("#eleButton").click(function(){
	$("#ele1").fadeToggle(500);
	$("#ele2").fadeToggle(500);
	$("#ele3").fadeToggle(500);
})

$("#modButton").click(function(){
	$("#mod1").fadeToggle(500);
	$("#mod2").fadeToggle(500);
	$("#mod3").fadeToggle(500);
})